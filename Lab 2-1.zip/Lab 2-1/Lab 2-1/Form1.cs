﻿//Programmer: Dylan Stewart
//Project: Lab 2-1
// Date : 1/30/19
// Description: Form for taking a carpet order
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_2_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void lengthTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void widthLabel_Click(object sender, EventArgs e)
        {

        }

        private void lengthLabel_Click(object sender, EventArgs e)
        {

        }

        private void titleLabel_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void taxLabel_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // try catch to handle data exceptions
            try
            {
                //declare local constants
                const decimal TAX_RATE = 0.07m;
                const decimal LABOR_RATE = 0.50m;

                //declare local variables
                double length;
                double width;
                double area;
                decimal price;
                decimal carpetCharge;
                decimal tax;
                decimal laborCharge;
                decimal orderTotal;

                // Get Values from text box and assign them to variables
                length = double.Parse(lengthTextBox.Text);
                width = double.Parse(widthTextBox.Text);
                price = decimal.Parse(priceTextBox.Text);

                // Calculate and display area of carpet
                area = length * width;
                areaLabel.Text = area.ToString("n2");

                // Calculate and display carpet charge price
                carpetCharge = (decimal)area * price;
                carpetChargeLabel.Text = carpetCharge.ToString("c");

                // Calculate and display tax rate
                tax = carpetCharge * TAX_RATE;
                taxLabel.Text = tax.ToString("c");

                // calculate and display labor charge
                laborCharge = (decimal)area * LABOR_RATE;
                laborChargeLabel.Text = laborCharge.ToString("c");

                // calculate and display order total
                orderTotal = carpetCharge + tax + laborCharge;
                orderTotalLabel.Text = orderTotal.ToString("c");
            }
            catch (Exception ex)
            {
                // Display default error message
                MessageBox.Show(ex.Message);
            }
        }

        //clear all input and output controls 
       
       
private void clearButton_Click_1(object sender, EventArgs e)
        {
            lengthTextBox.Text = "";
            widthTextBox.Text = "";
            priceTextBox.Text = "";
            areaLabel.Text = "";
            carpetChargeLabel.Text = "";
            taxLabel.Text = "";

            // Set focus to first input control on form
            lengthTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
        }
    

