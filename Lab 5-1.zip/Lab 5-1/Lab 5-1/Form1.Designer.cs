﻿namespace Lab_5_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.iceCreamPictureBox = new System.Windows.Forms.PictureBox();
            this.coneLabel = new System.Windows.Forms.Label();
            this.sugarConeadioButton = new System.Windows.Forms.RadioButton();
            this.waffleConeRadioButton = new System.Windows.Forms.RadioButton();
            this.flavorLabel = new System.Windows.Forms.Label();
            this.flavorComboBox = new System.Windows.Forms.ComboBox();
            this.toppingListBox = new System.Windows.Forms.ListBox();
            this.toppingsLabel = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.iceCreamPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // iceCreamPictureBox
            // 
            this.iceCreamPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.iceCreamPictureBox.Image = global::Lab_5_1.Properties.Resources.cones;
            this.iceCreamPictureBox.InitialImage = null;
            this.iceCreamPictureBox.Location = new System.Drawing.Point(69, 12);
            this.iceCreamPictureBox.Name = "iceCreamPictureBox";
            this.iceCreamPictureBox.Size = new System.Drawing.Size(304, 143);
            this.iceCreamPictureBox.TabIndex = 0;
            this.iceCreamPictureBox.TabStop = false;
            // 
            // coneLabel
            // 
            this.coneLabel.AutoSize = true;
            this.coneLabel.Location = new System.Drawing.Point(39, 184);
            this.coneLabel.Name = "coneLabel";
            this.coneLabel.Size = new System.Drawing.Size(81, 17);
            this.coneLabel.TabIndex = 1;
            this.coneLabel.Text = "Cone Type:";
            // 
            // sugarConeadioButton
            // 
            this.sugarConeadioButton.AutoSize = true;
            this.sugarConeadioButton.Location = new System.Drawing.Point(127, 184);
            this.sugarConeadioButton.Name = "sugarConeadioButton";
            this.sugarConeadioButton.Size = new System.Drawing.Size(104, 21);
            this.sugarConeadioButton.TabIndex = 2;
            this.sugarConeadioButton.TabStop = true;
            this.sugarConeadioButton.Text = "Sugar Cone";
            this.sugarConeadioButton.UseVisualStyleBackColor = true;
            // 
            // waffleConeRadioButton
            // 
            this.waffleConeRadioButton.AutoSize = true;
            this.waffleConeRadioButton.Location = new System.Drawing.Point(238, 184);
            this.waffleConeRadioButton.Name = "waffleConeRadioButton";
            this.waffleConeRadioButton.Size = new System.Drawing.Size(106, 21);
            this.waffleConeRadioButton.TabIndex = 3;
            this.waffleConeRadioButton.TabStop = true;
            this.waffleConeRadioButton.Text = "Waffle Cone";
            this.waffleConeRadioButton.UseVisualStyleBackColor = true;
            // 
            // flavorLabel
            // 
            this.flavorLabel.AutoSize = true;
            this.flavorLabel.Location = new System.Drawing.Point(81, 239);
            this.flavorLabel.Name = "flavorLabel";
            this.flavorLabel.Size = new System.Drawing.Size(118, 17);
            this.flavorLabel.TabIndex = 4;
            this.flavorLabel.Text = "Ice Cream Flavor:";
            // 
            // flavorComboBox
            // 
            this.flavorComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.flavorComboBox.FormattingEnabled = true;
            this.flavorComboBox.Location = new System.Drawing.Point(220, 239);
            this.flavorComboBox.Name = "flavorComboBox";
            this.flavorComboBox.Size = new System.Drawing.Size(121, 24);
            this.flavorComboBox.TabIndex = 5;
            // 
            // toppingListBox
            // 
            this.toppingListBox.FormattingEnabled = true;
            this.toppingListBox.ItemHeight = 16;
            this.toppingListBox.Location = new System.Drawing.Point(221, 295);
            this.toppingListBox.Name = "toppingListBox";
            this.toppingListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.toppingListBox.Size = new System.Drawing.Size(152, 100);
            this.toppingListBox.TabIndex = 6;
            // 
            // toppingsLabel
            // 
            this.toppingsLabel.AutoSize = true;
            this.toppingsLabel.Location = new System.Drawing.Point(124, 295);
            this.toppingsLabel.Name = "toppingsLabel";
            this.toppingsLabel.Size = new System.Drawing.Size(71, 17);
            this.toppingsLabel.TabIndex = 7;
            this.toppingsLabel.Text = "Toppings:";
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(120, 415);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 31);
            this.saveButton.TabIndex = 8;
            this.saveButton.Text = "&Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(269, 415);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 31);
            this.exitButton.TabIndex = 9;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(441, 480);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.toppingsLabel);
            this.Controls.Add(this.toppingListBox);
            this.Controls.Add(this.flavorComboBox);
            this.Controls.Add(this.flavorLabel);
            this.Controls.Add(this.waffleConeRadioButton);
            this.Controls.Add(this.sugarConeadioButton);
            this.Controls.Add(this.coneLabel);
            this.Controls.Add(this.iceCreamPictureBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.iceCreamPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox iceCreamPictureBox;
        private System.Windows.Forms.Label coneLabel;
        private System.Windows.Forms.RadioButton sugarConeadioButton;
        private System.Windows.Forms.RadioButton waffleConeRadioButton;
        private System.Windows.Forms.Label flavorLabel;
        private System.Windows.Forms.ComboBox flavorComboBox;
        private System.Windows.Forms.ListBox toppingListBox;
        private System.Windows.Forms.Label toppingsLabel;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button exitButton;
    }
}

