﻿// Programmer: Dylan Stewart
// Project: Lab 1-2
// Date: 01/19/19
// Description: The four seasons application
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_1_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Displays the fall image 
        private void button1_Click(object sender, EventArgs e)
        {
            seasonsPictureBox.Image = Lab_1_2.Properties.Resources.Fall;
        }
        //displays spring image 
        private void button3_Click(object sender, EventArgs e)
        {
            seasonsPictureBox.Image = Lab_1_2.Properties.Resources.Spring;
        }
        //displays winter image
        private void winterButton_Click(object sender, EventArgs e)
        {
            seasonsPictureBox.Image = Lab_1_2.Properties.Resources.Winter;
        }
        //displays summer image
        private void summerButton_Click(object sender, EventArgs e)
        {
            seasonsPictureBox.Image = Lab_1_2.Properties.Resources.Summer;
        }
        //closes the application
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
