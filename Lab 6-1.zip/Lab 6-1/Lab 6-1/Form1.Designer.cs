﻿namespace Lab_5_1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.coneLabel = new System.Windows.Forms.Label();
            this.sugarConeadioButton = new System.Windows.Forms.RadioButton();
            this.waffleConeRadioButton = new System.Windows.Forms.RadioButton();
            this.flavorLabel = new System.Windows.Forms.Label();
            this.flavorComboBox = new System.Windows.Forms.ComboBox();
            this.toppingListBox = new System.Windows.Forms.ListBox();
            this.toppingsLabel = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iceCreamPictureBox = new System.Windows.Forms.PictureBox();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iceCreamPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // coneLabel
            // 
            this.coneLabel.AutoSize = true;
            this.coneLabel.Location = new System.Drawing.Point(28, 212);
            this.coneLabel.Name = "coneLabel";
            this.coneLabel.Size = new System.Drawing.Size(81, 17);
            this.coneLabel.TabIndex = 1;
            this.coneLabel.Text = "Cone Type:";
            // 
            // sugarConeadioButton
            // 
            this.sugarConeadioButton.AutoSize = true;
            this.sugarConeadioButton.Location = new System.Drawing.Point(116, 212);
            this.sugarConeadioButton.Name = "sugarConeadioButton";
            this.sugarConeadioButton.Size = new System.Drawing.Size(104, 21);
            this.sugarConeadioButton.TabIndex = 2;
            this.sugarConeadioButton.TabStop = true;
            this.sugarConeadioButton.Text = "Sugar Cone";
            this.sugarConeadioButton.UseVisualStyleBackColor = true;
            // 
            // waffleConeRadioButton
            // 
            this.waffleConeRadioButton.AutoSize = true;
            this.waffleConeRadioButton.Location = new System.Drawing.Point(227, 212);
            this.waffleConeRadioButton.Name = "waffleConeRadioButton";
            this.waffleConeRadioButton.Size = new System.Drawing.Size(106, 21);
            this.waffleConeRadioButton.TabIndex = 3;
            this.waffleConeRadioButton.TabStop = true;
            this.waffleConeRadioButton.Text = "Waffle Cone";
            this.waffleConeRadioButton.UseVisualStyleBackColor = true;
            // 
            // flavorLabel
            // 
            this.flavorLabel.AutoSize = true;
            this.flavorLabel.Location = new System.Drawing.Point(70, 267);
            this.flavorLabel.Name = "flavorLabel";
            this.flavorLabel.Size = new System.Drawing.Size(118, 17);
            this.flavorLabel.TabIndex = 4;
            this.flavorLabel.Text = "Ice Cream Flavor:";
            // 
            // flavorComboBox
            // 
            this.flavorComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.flavorComboBox.FormattingEnabled = true;
            this.flavorComboBox.Location = new System.Drawing.Point(209, 267);
            this.flavorComboBox.Name = "flavorComboBox";
            this.flavorComboBox.Size = new System.Drawing.Size(121, 24);
            this.flavorComboBox.TabIndex = 5;
            // 
            // toppingListBox
            // 
            this.toppingListBox.FormattingEnabled = true;
            this.toppingListBox.ItemHeight = 16;
            this.toppingListBox.Location = new System.Drawing.Point(210, 323);
            this.toppingListBox.Name = "toppingListBox";
            this.toppingListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.toppingListBox.Size = new System.Drawing.Size(152, 100);
            this.toppingListBox.TabIndex = 6;
            // 
            // toppingsLabel
            // 
            this.toppingsLabel.AutoSize = true;
            this.toppingsLabel.Location = new System.Drawing.Point(113, 323);
            this.toppingsLabel.Name = "toppingsLabel";
            this.toppingsLabel.Size = new System.Drawing.Size(71, 17);
            this.toppingsLabel.TabIndex = 7;
            this.toppingsLabel.Text = "Toppings:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(441, 28);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(210, 26);
            this.saveToolStripMenuItem.Text = "&Save         Ctrl + S";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(210, 26);
            this.exitToolStripMenuItem.Text = "E&xit             Ctrl + X";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // iceCreamPictureBox
            // 
            this.iceCreamPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.iceCreamPictureBox.Image = global::Lab_6_1.Properties.Resources.cones;
            this.iceCreamPictureBox.InitialImage = null;
            this.iceCreamPictureBox.Location = new System.Drawing.Point(58, 40);
            this.iceCreamPictureBox.Name = "iceCreamPictureBox";
            this.iceCreamPictureBox.Size = new System.Drawing.Size(304, 143);
            this.iceCreamPictureBox.TabIndex = 0;
            this.iceCreamPictureBox.TabStop = false;
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(204, 26);
            this.aboutToolStripMenuItem.Text = "&About       Ctr l+ A";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(441, 493);
            this.Controls.Add(this.toppingsLabel);
            this.Controls.Add(this.toppingListBox);
            this.Controls.Add(this.flavorComboBox);
            this.Controls.Add(this.flavorLabel);
            this.Controls.Add(this.waffleConeRadioButton);
            this.Controls.Add(this.sugarConeadioButton);
            this.Controls.Add(this.coneLabel);
            this.Controls.Add(this.iceCreamPictureBox);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iceCreamPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox iceCreamPictureBox;
        private System.Windows.Forms.Label coneLabel;
        private System.Windows.Forms.RadioButton sugarConeadioButton;
        private System.Windows.Forms.RadioButton waffleConeRadioButton;
        private System.Windows.Forms.Label flavorLabel;
        private System.Windows.Forms.ComboBox flavorComboBox;
        private System.Windows.Forms.ListBox toppingListBox;
        private System.Windows.Forms.Label toppingsLabel;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
    }
}

