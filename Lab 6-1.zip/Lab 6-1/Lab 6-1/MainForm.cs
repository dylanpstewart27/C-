﻿//Programmer: Dylan Stewart
//Project Lab 5-1
// Date; 3/31/19
//Purpose: Ice Cream Order Form
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Lab_5_1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PopulateBoxes();

            // Default Combo box selection
            flavorComboBox.SelectedItem = "Vanilla";
        }

        // Custom method to fill combo and list boxes
        private void PopulateBoxes()
        {
            //Code to import text from files to the boxes
            try
            {
                StreamReader InputFile;

                InputFile = File.OpenText("Flavors.txt");
                while (!InputFile.EndOfStream)
                {
                    flavorComboBox.Items.Add(InputFile.ReadLine());
                }
                InputFile.Close();

                InputFile = File.OpenText("Toppings.txt");
                while (!InputFile.EndOfStream)
                {
                    toppingListBox.Items.Add(InputFile.ReadLine());
                }
                InputFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                this.Close();
            }
        }

       

       

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                StreamWriter outputFile;
                outputFile = File.AppendText("Orders.txt");

                outputFile.WriteLine(DateTime.Now.ToString("MM/dd/yyyy"));

                // Determine cone type and write to file
                if (sugarConeadioButton.Checked)
                {
                    outputFile.WriteLine("Sugar Cone");
                }
                else
                {
                    outputFile.WriteLine("Waffle Cone");
                }

                //Write selected ice cream flavor to file
                outputFile.WriteLine(flavorComboBox.SelectedItem.ToString());

                //loop through all items in list box and write selected items to output file
                for (int count = 0; count < toppingListBox.Items.Count; count++)
                {
                    if (toppingListBox.GetSelected(count))
                    {
                        outputFile.WriteLine(toppingListBox.Items[count]);
                    }
                }

                outputFile.WriteLine();
                outputFile.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            //Revert Form
            sugarConeadioButton.Checked = true;
            flavorComboBox.SelectedItem = "Vanilla";
            toppingListBox.ClearSelected();
            sugarConeadioButton.Focus();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Display form
            AboutForm myAboutForm = new AboutForm();
            myAboutForm.ShowDialog();
        }
    }
}
