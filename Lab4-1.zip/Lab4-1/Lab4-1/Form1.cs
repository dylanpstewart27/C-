﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Lab4_1
{
    public partial class Form1 : Form
    {
        //declare class level constants for tax rates and commission rates
        private const decimal STATE_SALES_TAX_RATE = 0.06m;
        private const decimal HILLSBOROUGH_SALES_TAX_RATE = 0.01m;
        private const decimal PASCO_SALES_TAX_RATE = 0m;
        private const decimal POLK_SALES_TAX_RATE = 0.005m;
        private const decimal RESIDENTIAL_COMMISSION_RATE = 0.06m;
        private const decimal COMMERCIAL_COMMISSION_RATE = 0.05m;

        //declare class level variables used for calculations of totals
        private decimal propertyPrice = 0m;
        private decimal stateSalesTax = 0m;
        private decimal countrySalesTax = 0m;
        private decimal commission = 0m;
        private decimal totalPrice = 0m;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Display the current date
            saleDateMaskedTextBox.Text = DateTime.Now.ToString("MM/dd/yyyy");

            //Disable the save button until a proper value is entered
            saveButton.Enabled = false;
        }

        private void propertyPriceTextBox_TextChanged(object sender, EventArgs e)
        {
            saveButton.Enabled = false; //Disable the save button until the update tool method runs
        }

        //Custom method to update total fields
        private void UpdateTotals()
        {
            //Read the price of the property entered by the user
            if (decimal.TryParse(propertyPriceTextBox.Text, out propertyPrice))
            {
                //Set property price variable equal to text property of text box
                propertyPrice = decimal.Parse(propertyPriceTextBox.Text);

                // Calculate state sales tax amount
                stateSalesTax = propertyPrice * STATE_SALES_TAX_RATE;

                // Calculate county sales tax amount based on county selected
                if (hillsboroughRadioButton.Checked)
                {
                    countrySalesTax = propertyPrice * HILLSBOROUGH_SALES_TAX_RATE;
                }
                else if (pascoRadioButton.Checked)
                {
                    countrySalesTax = propertyPrice * PASCO_SALES_TAX_RATE;
                }
                else if (polkRadioButton.Checked)
                {
                    countrySalesTax = propertyPrice * POLK_SALES_TAX_RATE;
                }

                //calculate commission based on property type
                if (residentialRadioButton.Checked)
                {
                    commission = propertyPrice * RESIDENTIAL_COMMISSION_RATE;
                }
                else
                {
                    commission = propertyPrice * COMMERCIAL_COMMISSION_RATE;
                }

                // Calculate total price
                totalPrice = propertyPrice + stateSalesTax + countrySalesTax + commission;

                // Format and display calculated numeric values with currency formats
                stateSalesTaxLabel.Text = stateSalesTax.ToString("c");
                countySalesTaxLabel.Text = countrySalesTax.ToString("c");
                commissionLabel.Text = commission.ToString("c");
                totalPriceLabel.Text = totalPrice.ToString("c");

                if (propertyPrice > 0) //Verify that a price greater than zero has been entered
                {
                    saveButton.Enabled = true; // Enable the save button
                }
            }
            else // If null or non numeric value is entered
            {
                MessageBox.Show("You must enter a numeric value for Property Price." +
                    "\nEnter digits only (no dollar sign) for Property Price.",
                    "Blank Value or Non-Numeric Character Entered",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                propertyPriceTextBox.Focus(); //Send focus to property price text box
            }
        }

        private void hillsboroughRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotals();
        }

        private void pascoRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotals();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            try //Write data to external file
            {
                StreamWriter outputFile;
                outputFile = File.AppendText("Properties.txt");
                // Write data to file
                outputFile.WriteLine("Date: " + saleDateMaskedTextBox.Text);
                outputFile.WriteLine("Property Price: " + propertyPrice.ToString("c"));
                outputFile.WriteLine("State Sales Tax: " + stateSalesTax.ToString("c"));
                outputFile.WriteLine("County Sales Tax: " + countrySalesTax.ToString("c"));
                outputFile.WriteLine("Commission: " + commission.ToString("c"));
                outputFile.WriteLine("Total Price: " + totalPrice.ToString("c"));
                outputFile.WriteLine();
                outputFile.Close();

                MessageBox.Show("Data successfully saved to file.", "Confirmation",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                ClearForm(); // Call custom method to clear form
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ClearForm()
        {
            //Clear controls and reset form to original state
            saleDateMaskedTextBox.Text = DateTime.Now.ToString("MM/dd/yyyy");
            residentialRadioButton.Checked = true;
            hillsboroughRadioButton.Checked = true;
            propertyPriceTextBox.Text = "0.00";
            stateSalesTaxLabel.Text = "$0.00";
            countySalesTaxLabel.Text = "$0.00";
            commissionLabel.Text = "$0.00";
            totalPriceLabel.Text = "$0.00";
            saveButton.Enabled = false;
            propertyPriceTextBox.Focus();
        
        }

        //Closes the program
        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            UpdateTotals();
            saveButton.Focus();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            ClearForm();
        }
    }
}
