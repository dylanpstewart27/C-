﻿namespace Lab_3_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.petOwnerGroupBox = new System.Windows.Forms.GroupBox();
            this.ownerNameLabel = new System.Windows.Forms.Label();
            this.ownerPhoneLabel = new System.Windows.Forms.Label();
            this.ownerNameTextBox = new System.Windows.Forms.TextBox();
            this.ownerPhoneMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.petGroupBox = new System.Windows.Forms.GroupBox();
            this.petNameLabel = new System.Windows.Forms.Label();
            this.petNameTextBox = new System.Windows.Forms.TextBox();
            this.petDOBLabel = new System.Windows.Forms.Label();
            this.petDOBMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.petTypeLabel = new System.Windows.Forms.Label();
            this.catRadioButton = new System.Windows.Forms.RadioButton();
            this.dogRadioButton = new System.Windows.Forms.RadioButton();
            this.otherRadioButton = new System.Windows.Forms.RadioButton();
            this.typeIfOtherLabel = new System.Windows.Forms.Label();
            this.typeIfOtherTextBox = new System.Windows.Forms.TextBox();
            this.servicesGroupBox = new System.Windows.Forms.GroupBox();
            this.fleaRemovalCheckBox = new System.Windows.Forms.CheckBox();
            this.nailClippingCheckBox = new System.Windows.Forms.CheckBox();
            this.shampooCheckBox = new System.Windows.Forms.CheckBox();
            this.furTrimmingCheckBox = new System.Windows.Forms.CheckBox();
            this.fleaRemovalPriceLabel = new System.Windows.Forms.Label();
            this.nailClippingPriceLabel = new System.Windows.Forms.Label();
            this.shampooPriceLabel = new System.Windows.Forms.Label();
            this.furTrimmingPriceLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.totalFeeLabel = new System.Windows.Forms.Label();
            this.totalButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.quitButton = new System.Windows.Forms.Button();
            this.petOwnerGroupBox.SuspendLayout();
            this.petGroupBox.SuspendLayout();
            this.servicesGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // petOwnerGroupBox
            // 
            this.petOwnerGroupBox.Controls.Add(this.ownerPhoneMaskedTextBox);
            this.petOwnerGroupBox.Controls.Add(this.ownerNameTextBox);
            this.petOwnerGroupBox.Controls.Add(this.ownerPhoneLabel);
            this.petOwnerGroupBox.Controls.Add(this.ownerNameLabel);
            this.petOwnerGroupBox.Location = new System.Drawing.Point(12, 12);
            this.petOwnerGroupBox.Name = "petOwnerGroupBox";
            this.petOwnerGroupBox.Size = new System.Drawing.Size(449, 105);
            this.petOwnerGroupBox.TabIndex = 0;
            this.petOwnerGroupBox.TabStop = false;
            this.petOwnerGroupBox.Text = "Pet Owner";
            // 
            // ownerNameLabel
            // 
            this.ownerNameLabel.AutoSize = true;
            this.ownerNameLabel.Location = new System.Drawing.Point(6, 29);
            this.ownerNameLabel.Name = "ownerNameLabel";
            this.ownerNameLabel.Size = new System.Drawing.Size(94, 17);
            this.ownerNameLabel.TabIndex = 0;
            this.ownerNameLabel.Text = "&Owner Name:";
            // 
            // ownerPhoneLabel
            // 
            this.ownerPhoneLabel.AutoSize = true;
            this.ownerPhoneLabel.Location = new System.Drawing.Point(6, 56);
            this.ownerPhoneLabel.Name = "ownerPhoneLabel";
            this.ownerPhoneLabel.Size = new System.Drawing.Size(98, 17);
            this.ownerPhoneLabel.TabIndex = 1;
            this.ownerPhoneLabel.Text = "O&wner Phone:";
            // 
            // ownerNameTextBox
            // 
            this.ownerNameTextBox.Location = new System.Drawing.Point(142, 29);
            this.ownerNameTextBox.Name = "ownerNameTextBox";
            this.ownerNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.ownerNameTextBox.TabIndex = 2;
            // 
            // ownerPhoneMaskedTextBox
            // 
            this.ownerPhoneMaskedTextBox.Location = new System.Drawing.Point(142, 57);
            this.ownerPhoneMaskedTextBox.Mask = "(999) 000-0000";
            this.ownerPhoneMaskedTextBox.Name = "ownerPhoneMaskedTextBox";
            this.ownerPhoneMaskedTextBox.Size = new System.Drawing.Size(100, 22);
            this.ownerPhoneMaskedTextBox.TabIndex = 3;
            // 
            // petGroupBox
            // 
            this.petGroupBox.Controls.Add(this.typeIfOtherTextBox);
            this.petGroupBox.Controls.Add(this.typeIfOtherLabel);
            this.petGroupBox.Controls.Add(this.otherRadioButton);
            this.petGroupBox.Controls.Add(this.dogRadioButton);
            this.petGroupBox.Controls.Add(this.catRadioButton);
            this.petGroupBox.Controls.Add(this.petTypeLabel);
            this.petGroupBox.Controls.Add(this.petDOBMaskedTextBox);
            this.petGroupBox.Controls.Add(this.petDOBLabel);
            this.petGroupBox.Controls.Add(this.petNameTextBox);
            this.petGroupBox.Controls.Add(this.petNameLabel);
            this.petGroupBox.Location = new System.Drawing.Point(12, 133);
            this.petGroupBox.Name = "petGroupBox";
            this.petGroupBox.Size = new System.Drawing.Size(449, 152);
            this.petGroupBox.TabIndex = 4;
            this.petGroupBox.TabStop = false;
            this.petGroupBox.Text = "Pet";
            this.petGroupBox.Enter += new System.EventHandler(this.petGroupBox_Enter);
            // 
            // petNameLabel
            // 
            this.petNameLabel.AutoSize = true;
            this.petNameLabel.Location = new System.Drawing.Point(6, 29);
            this.petNameLabel.Name = "petNameLabel";
            this.petNameLabel.Size = new System.Drawing.Size(74, 17);
            this.petNameLabel.TabIndex = 0;
            this.petNameLabel.Text = "&Pet Name:";
            // 
            // petNameTextBox
            // 
            this.petNameTextBox.Location = new System.Drawing.Point(142, 29);
            this.petNameTextBox.Name = "petNameTextBox";
            this.petNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.petNameTextBox.TabIndex = 1;
            // 
            // petDOBLabel
            // 
            this.petDOBLabel.AutoSize = true;
            this.petDOBLabel.Location = new System.Drawing.Point(6, 57);
            this.petDOBLabel.Name = "petDOBLabel";
            this.petDOBLabel.Size = new System.Drawing.Size(116, 17);
            this.petDOBLabel.TabIndex = 2;
            this.petDOBLabel.Text = "Pet Date of Birth:";
            // 
            // petDOBMaskedTextBox
            // 
            this.petDOBMaskedTextBox.Location = new System.Drawing.Point(142, 57);
            this.petDOBMaskedTextBox.Mask = "00/00/0000";
            this.petDOBMaskedTextBox.Name = "petDOBMaskedTextBox";
            this.petDOBMaskedTextBox.Size = new System.Drawing.Size(100, 22);
            this.petDOBMaskedTextBox.TabIndex = 4;
            this.petDOBMaskedTextBox.ValidatingType = typeof(System.DateTime);
            // 
            // petTypeLabel
            // 
            this.petTypeLabel.AutoSize = true;
            this.petTypeLabel.Location = new System.Drawing.Point(6, 84);
            this.petTypeLabel.Name = "petTypeLabel";
            this.petTypeLabel.Size = new System.Drawing.Size(69, 17);
            this.petTypeLabel.TabIndex = 5;
            this.petTypeLabel.Text = "Pet Type:";
            this.petTypeLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // catRadioButton
            // 
            this.catRadioButton.AutoSize = true;
            this.catRadioButton.Checked = true;
            this.catRadioButton.Location = new System.Drawing.Point(142, 82);
            this.catRadioButton.Name = "catRadioButton";
            this.catRadioButton.Size = new System.Drawing.Size(50, 21);
            this.catRadioButton.TabIndex = 6;
            this.catRadioButton.TabStop = true;
            this.catRadioButton.Text = "Cat";
            this.catRadioButton.UseVisualStyleBackColor = true;
            // 
            // dogRadioButton
            // 
            this.dogRadioButton.AutoSize = true;
            this.dogRadioButton.Location = new System.Drawing.Point(203, 84);
            this.dogRadioButton.Name = "dogRadioButton";
            this.dogRadioButton.Size = new System.Drawing.Size(55, 21);
            this.dogRadioButton.TabIndex = 7;
            this.dogRadioButton.TabStop = true;
            this.dogRadioButton.Text = "Dog";
            this.dogRadioButton.UseVisualStyleBackColor = true;
            // 
            // otherRadioButton
            // 
            this.otherRadioButton.AutoSize = true;
            this.otherRadioButton.Location = new System.Drawing.Point(264, 84);
            this.otherRadioButton.Name = "otherRadioButton";
            this.otherRadioButton.Size = new System.Drawing.Size(65, 21);
            this.otherRadioButton.TabIndex = 8;
            this.otherRadioButton.TabStop = true;
            this.otherRadioButton.Text = "Other";
            this.otherRadioButton.UseVisualStyleBackColor = true;
            this.otherRadioButton.CheckedChanged += new System.EventHandler(this.otherRadioButton_CheckedChanged);
            // 
            // typeIfOtherLabel
            // 
            this.typeIfOtherLabel.AutoSize = true;
            this.typeIfOtherLabel.Enabled = false;
            this.typeIfOtherLabel.Location = new System.Drawing.Point(139, 121);
            this.typeIfOtherLabel.Name = "typeIfOtherLabel";
            this.typeIfOtherLabel.Size = new System.Drawing.Size(105, 17);
            this.typeIfOtherLabel.TabIndex = 5;
            this.typeIfOtherLabel.Text = "Type (if Other):";
            // 
            // typeIfOtherTextBox
            // 
            this.typeIfOtherTextBox.Enabled = false;
            this.typeIfOtherTextBox.Location = new System.Drawing.Point(250, 121);
            this.typeIfOtherTextBox.Name = "typeIfOtherTextBox";
            this.typeIfOtherTextBox.Size = new System.Drawing.Size(100, 22);
            this.typeIfOtherTextBox.TabIndex = 9;
            // 
            // servicesGroupBox
            // 
            this.servicesGroupBox.Controls.Add(this.totalFeeLabel);
            this.servicesGroupBox.Controls.Add(this.totalLabel);
            this.servicesGroupBox.Controls.Add(this.furTrimmingPriceLabel);
            this.servicesGroupBox.Controls.Add(this.shampooPriceLabel);
            this.servicesGroupBox.Controls.Add(this.nailClippingPriceLabel);
            this.servicesGroupBox.Controls.Add(this.fleaRemovalPriceLabel);
            this.servicesGroupBox.Controls.Add(this.furTrimmingCheckBox);
            this.servicesGroupBox.Controls.Add(this.shampooCheckBox);
            this.servicesGroupBox.Controls.Add(this.nailClippingCheckBox);
            this.servicesGroupBox.Controls.Add(this.fleaRemovalCheckBox);
            this.servicesGroupBox.Location = new System.Drawing.Point(21, 313);
            this.servicesGroupBox.Name = "servicesGroupBox";
            this.servicesGroupBox.Size = new System.Drawing.Size(440, 157);
            this.servicesGroupBox.TabIndex = 5;
            this.servicesGroupBox.TabStop = false;
            this.servicesGroupBox.Text = "Services";
            // 
            // fleaRemovalCheckBox
            // 
            this.fleaRemovalCheckBox.AutoSize = true;
            this.fleaRemovalCheckBox.Location = new System.Drawing.Point(6, 35);
            this.fleaRemovalCheckBox.Name = "fleaRemovalCheckBox";
            this.fleaRemovalCheckBox.Size = new System.Drawing.Size(116, 21);
            this.fleaRemovalCheckBox.TabIndex = 0;
            this.fleaRemovalCheckBox.Text = "Flea Removal";
            this.fleaRemovalCheckBox.UseVisualStyleBackColor = true;
            // 
            // nailClippingCheckBox
            // 
            this.nailClippingCheckBox.AutoSize = true;
            this.nailClippingCheckBox.Location = new System.Drawing.Point(6, 74);
            this.nailClippingCheckBox.Name = "nailClippingCheckBox";
            this.nailClippingCheckBox.Size = new System.Drawing.Size(108, 21);
            this.nailClippingCheckBox.TabIndex = 1;
            this.nailClippingCheckBox.Text = "Nail Clipping";
            this.nailClippingCheckBox.UseVisualStyleBackColor = true;
            // 
            // shampooCheckBox
            // 
            this.shampooCheckBox.AutoSize = true;
            this.shampooCheckBox.Location = new System.Drawing.Point(194, 35);
            this.shampooCheckBox.Name = "shampooCheckBox";
            this.shampooCheckBox.Size = new System.Drawing.Size(90, 21);
            this.shampooCheckBox.TabIndex = 2;
            this.shampooCheckBox.Text = "Shampoo";
            this.shampooCheckBox.UseVisualStyleBackColor = true;
            // 
            // furTrimmingCheckBox
            // 
            this.furTrimmingCheckBox.AutoSize = true;
            this.furTrimmingCheckBox.Location = new System.Drawing.Point(194, 74);
            this.furTrimmingCheckBox.Name = "furTrimmingCheckBox";
            this.furTrimmingCheckBox.Size = new System.Drawing.Size(113, 21);
            this.furTrimmingCheckBox.TabIndex = 3;
            this.furTrimmingCheckBox.Text = "Fur Trimming";
            this.furTrimmingCheckBox.UseVisualStyleBackColor = true;
            // 
            // fleaRemovalPriceLabel
            // 
            this.fleaRemovalPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fleaRemovalPriceLabel.Location = new System.Drawing.Point(130, 35);
            this.fleaRemovalPriceLabel.Name = "fleaRemovalPriceLabel";
            this.fleaRemovalPriceLabel.Size = new System.Drawing.Size(58, 23);
            this.fleaRemovalPriceLabel.TabIndex = 4;
            // 
            // nailClippingPriceLabel
            // 
            this.nailClippingPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nailClippingPriceLabel.Location = new System.Drawing.Point(130, 74);
            this.nailClippingPriceLabel.Name = "nailClippingPriceLabel";
            this.nailClippingPriceLabel.Size = new System.Drawing.Size(58, 23);
            this.nailClippingPriceLabel.TabIndex = 5;
            // 
            // shampooPriceLabel
            // 
            this.shampooPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.shampooPriceLabel.Location = new System.Drawing.Point(313, 35);
            this.shampooPriceLabel.Name = "shampooPriceLabel";
            this.shampooPriceLabel.Size = new System.Drawing.Size(58, 23);
            this.shampooPriceLabel.TabIndex = 6;
            // 
            // furTrimmingPriceLabel
            // 
            this.furTrimmingPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.furTrimmingPriceLabel.Location = new System.Drawing.Point(313, 75);
            this.furTrimmingPriceLabel.Name = "furTrimmingPriceLabel";
            this.furTrimmingPriceLabel.Size = new System.Drawing.Size(58, 23);
            this.furTrimmingPriceLabel.TabIndex = 7;
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Location = new System.Drawing.Point(130, 120);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(72, 17);
            this.totalLabel.TabIndex = 8;
            this.totalLabel.Text = "Total Fee:";
            // 
            // totalFeeLabel
            // 
            this.totalFeeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalFeeLabel.Location = new System.Drawing.Point(208, 120);
            this.totalFeeLabel.Name = "totalFeeLabel";
            this.totalFeeLabel.Size = new System.Drawing.Size(58, 23);
            this.totalFeeLabel.TabIndex = 9;
            this.totalFeeLabel.Click += new System.EventHandler(this.label6_Click);
            // 
            // totalButton
            // 
            this.totalButton.Location = new System.Drawing.Point(41, 503);
            this.totalButton.Name = "totalButton";
            this.totalButton.Size = new System.Drawing.Size(75, 23);
            this.totalButton.TabIndex = 10;
            this.totalButton.Text = "Total";
            this.totalButton.UseVisualStyleBackColor = true;
            this.totalButton.Click += new System.EventHandler(this.totalButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(179, 503);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 11;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // quitButton
            // 
            this.quitButton.Location = new System.Drawing.Point(317, 503);
            this.quitButton.Name = "quitButton";
            this.quitButton.Size = new System.Drawing.Size(75, 23);
            this.quitButton.TabIndex = 12;
            this.quitButton.Text = "Quit";
            this.quitButton.UseVisualStyleBackColor = true;
            this.quitButton.Click += new System.EventHandler(this.quitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(473, 553);
            this.Controls.Add(this.quitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.totalButton);
            this.Controls.Add(this.servicesGroupBox);
            this.Controls.Add(this.petGroupBox);
            this.Controls.Add(this.petOwnerGroupBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.petOwnerGroupBox.ResumeLayout(false);
            this.petOwnerGroupBox.PerformLayout();
            this.petGroupBox.ResumeLayout(false);
            this.petGroupBox.PerformLayout();
            this.servicesGroupBox.ResumeLayout(false);
            this.servicesGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox petOwnerGroupBox;
        private System.Windows.Forms.MaskedTextBox ownerPhoneMaskedTextBox;
        private System.Windows.Forms.TextBox ownerNameTextBox;
        private System.Windows.Forms.Label ownerPhoneLabel;
        private System.Windows.Forms.Label ownerNameLabel;
        private System.Windows.Forms.GroupBox petGroupBox;
        private System.Windows.Forms.TextBox petNameTextBox;
        private System.Windows.Forms.Label petNameLabel;
        private System.Windows.Forms.Label petTypeLabel;
        private System.Windows.Forms.MaskedTextBox petDOBMaskedTextBox;
        private System.Windows.Forms.Label petDOBLabel;
        private System.Windows.Forms.TextBox typeIfOtherTextBox;
        private System.Windows.Forms.Label typeIfOtherLabel;
        private System.Windows.Forms.RadioButton otherRadioButton;
        private System.Windows.Forms.RadioButton dogRadioButton;
        private System.Windows.Forms.RadioButton catRadioButton;
        private System.Windows.Forms.GroupBox servicesGroupBox;
        private System.Windows.Forms.Label nailClippingPriceLabel;
        private System.Windows.Forms.Label fleaRemovalPriceLabel;
        private System.Windows.Forms.CheckBox furTrimmingCheckBox;
        private System.Windows.Forms.CheckBox shampooCheckBox;
        private System.Windows.Forms.CheckBox nailClippingCheckBox;
        private System.Windows.Forms.CheckBox fleaRemovalCheckBox;
        private System.Windows.Forms.Label furTrimmingPriceLabel;
        private System.Windows.Forms.Label shampooPriceLabel;
        private System.Windows.Forms.Label totalFeeLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Button totalButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button quitButton;
    }
}

